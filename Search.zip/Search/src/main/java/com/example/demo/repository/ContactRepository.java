package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entities.Contact;


public interface ContactRepository extends JpaRepository<Contact, Integer>{
	@Query("select cont from Contact cont where cont.name = :name")
	public Contact getContactByName(@Param("name")String name);

}
