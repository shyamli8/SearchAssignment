package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Contact;
import com.example.demo.repository.ContactRepository;

@Service
public class ContactService {
	@Autowired
	public ContactRepository conRepo;
	public Contact getContact(String name) {
		return conRepo.getContactByName(name);
	}

}
