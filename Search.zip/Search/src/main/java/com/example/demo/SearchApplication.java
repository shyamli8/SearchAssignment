package com.example.demo;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.entities.Contact;
import com.example.demo.service.ContactService;

@SpringBootApplication
public class SearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(SearchApplication.class, args);
		System.out.println("Enter name to find contact");
		Scanner sc=new Scanner(System.in);
		String name=sc.nextLine();
		ContactService conServ=new ContactService();
		Contact c=conServ.getContact(name);
		System.out.println(c.getName());
		System.out.println(c.getSurname());
		System.out.println(c.getAddress());
		System.out.println(c.getCity());
		System.out.println(c.getState());
		System.out.println(c.getZipcode());
		
	}

}
